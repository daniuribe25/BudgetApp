export class UsuarioDTO {

    user: string;
    pass: string;
}