import { Component, Input } from '@angular/core';

import { NavController } from 'ionic-angular';
import { UsuarioDTO } from "./UsuarioDTO";

@Component({
    selector: 'page-home',
    templateUrl: 'home.html'
})
export class HomePage {
   user:string;
   pass:string;
   
    constructor(public navCtrl: NavController) {
        
    }

    validarCredenciales() {
        console.log(this.user);
        console.log(this.pass);
    }
}